const express = require('express');
const router = express.Router();
const mongoose = require('mongoose')
require('models/Cocktail') 
const CocktailVariable = mongoose.model('Cocktail');
const fs = require('fs/promises');
const path = require('path');

// Fallback if data isn't pulled
const readRecipesFromFile = async () => {
  try {
    const filePath = path.join(__dirname, '../../../models/recipes.json');
    const data = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    throw new Error('Error reading recipes from file: ' + error.message);
  }
};

router.get('/Cocktail', async (req, res) => {
  try {
    console.log('Cocktail API Router is up!');
    const cocktails = await CocktailVariable.find();
    console.log(cocktails)
    if (cocktails.length === 0) {
      // If no cocktails found in the database, read from recipes.json file
      const recipes = await readRecipesFromFile();
      const recipeNames = recipes.map(recipe => recipe.name);
      res.json(recipeNames)
    } else {
      res.json(cocktails)
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
});

router.get('/Cocktail/name/:name', async (req, res) => {
  try {
    const name = req.params.name;
    const filter = { name: name };
    const cocktails = await CocktailVariable.find(filter);
    if (cocktails.length === 0) {
      const recipes = await readRecipesFromFile();
      res.json(recipes);
    } else {
      res.json(cocktails);
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;