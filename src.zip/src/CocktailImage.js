import React from 'react';
import recipesData from './recipes.json';

const CocktailImage = ({ cocktailData }) => {
  if (!cocktailData) {
    return null;
  }
  const { image } = cocktailData;

  let imagePath = ''; 

  if (image) {
    imagePath = require(`./images/${image}`).default; 
  } else {
    if (recipesData.length > 0) {
      const firstRecipe = recipesData[0]; 
      const fallbackImage = firstRecipe.image || 'Shaker.jpg'; 
      imagePath = require(`./images/${fallbackImage}`).default; 
    }
  }

  return (
    <div>
      <img src={imagePath} alt={image} style={{ maxWidth: '100%' }} />
    </div>
  );
};

export default CocktailImage;
