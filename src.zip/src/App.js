import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import CocktailList from './CocktailList';

function App() {
  return (
    <div>
      <CocktailList />
    </div>
  );
}

export default App;
