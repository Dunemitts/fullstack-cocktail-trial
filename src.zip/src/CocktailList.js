import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import Ingredient from './Ingredient';
import CocktailImage from './CocktailImage';
import recipesData from './recipes.json'; // In case mongodb link doesn't work

const CocktailList = () => {
  const [cocktails, setCocktails] = useState([]);
  const [selectedCocktail, setSelectedCocktail] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:8080/api/v1/Cocktail`)
      .then((response) => {
        console.log(response.data);
        setCocktails(response.data);
      })
      .catch((error) => {
        console.error("Error Response:");
        console.error(error.response.data);
        console.error(error.response.status);
        console.error(error.response.headers);
      });
  }, []);

  const handleCocktailClick = async (name) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/v1/Cocktail/${name}`);
      setSelectedCocktail(response.data);
    } catch (error) {
      console.error(error);
      const selected = recipesData.find(cocktail => cocktail.name === name); // Fallback
      setSelectedCocktail(selected);
    } 
  };  

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredCocktails = cocktails.filter(cocktailName =>
    cocktailName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="App">
      <h1>Cocktail Recipes</h1>
      <div className="cocktail-content">
        <div className="cocktail-list-container">
      <div className="search-bar">
       <input
        type="text"
        placeholder="Search by cocktail name"
        value={searchTerm}
        onChange={handleSearch}
      /> 
      </div>
      <div className="cocktail-list">
        {filteredCocktails.map(cocktailName => (
          <div
            key={cocktailName}
            className="cocktail-card"
            onClick={() => handleCocktailClick(cocktailName)}
          >
            <h2>{cocktailName}</h2>
          </div>
        ))}
      </div>
      </div>
      {selectedCocktail && (
        <div className="selected-cocktail">
          <h2>{selectedCocktail.name}</h2>
          <CocktailImage cocktailData={selectedCocktail} />
          <Ingredient ingredients={selectedCocktail.ingredients} />
        </div>
      )}
      </div>
    </div>
  );
};

export default CocktailList;