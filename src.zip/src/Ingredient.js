import React from 'react';

const Ingredient = ({ ingredients }) => {
  if (!ingredients || !Array.isArray(ingredients)) {
    return <div>No ingredients available</div>;
  }

  return (
    <div>
      <h3>Ingredients</h3>
      <ul>
        {ingredients.map((ingredient, index) => (
          <li key={index}>
            {ingredient.amount} {ingredient.unit} - {ingredient.ingredient}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Ingredient;
